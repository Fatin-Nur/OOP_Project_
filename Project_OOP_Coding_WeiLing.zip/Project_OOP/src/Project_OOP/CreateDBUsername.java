package Project_OOP;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDBUsername {
	
	public static void createNewDatabase(String filename) {
		String url = "jdbc:sqlite:C:/Users/ongwe/Desktop/" + filename;
		
		try {
			Class.forName("org.sqlite.JDBC");
			Connection con = DriverManager.getConnection(url);
			
			if(con!= null) {
				System.out.println("A new database has been created");
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
public static void createNewTable() {
		
		String url = "jdbc:sqlite:C:/Users/ongwe/Desktop/UserName2.db";
				
		String sql = "CREATE TABLE IF NOT EXISTS users (\n" 
				+ "username text PRIMARY KEY, \n"  
				+ "password text NOT NULL\n"
				+ ");";
		
		
		try {
			Class.forName("org.sqlite.JDBC");
			Connection con = DriverManager.getConnection(url);
			
			Statement stmt = con.createStatement();
			stmt.execute(sql);
			
			if(con !=null) {
				System.out.println("A new table has been created");
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}	
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		createNewDatabase("UserName2.db");
		createNewTable();
	}
}
