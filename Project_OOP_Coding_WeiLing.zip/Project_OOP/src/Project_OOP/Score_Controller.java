package Project_OOP;

import java.net.URL;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.swing.JOptionPane;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;

public class Score_Controller implements Initializable, ChangeScene{
	
	Student_Information_System main = new Student_Information_System();


    @FXML
    public TableView<Score> sc_table;

    @FXML
    public TableColumn<Score, Integer> col_id;

    @FXML
    public TableColumn<Score, String> col_course;

    @FXML
    public TableColumn<Score, Integer> col_score;

    @FXML
    public TextField sc_id;

    @FXML
    public TextField sc_score;

    @FXML
    public TextField sc_course;
    
    ObservableList<Score> listM;
    
	int index = -1;
	Connection con = null;
	ResultSet rs = null;
	PreparedStatement pst = null;
    

    @FXML
    public void addScore() {
    	
		con= SQLConnectScore.ConnectDB();
		String sql = " insert into scores(id,score,course)values(?,?,?)";
		try {
			pst = con.prepareStatement(sql);
			
			pst.setString(1, sc_id.getText());
			pst.setString(2, sc_score.getText());
			pst.setString(3, sc_course.getText());
			pst.execute();
			
			System.out.println("Score Add Success");
			
			//JOptionPane.showMessageDialog(null, "Score Add Success");
			UpdateTable();
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, e);
		}
    	
    }
    
    @FXML
    public void select(MouseEvent event) {
    	
		index= sc_table.getSelectionModel().getSelectedIndex();
		if(index<=-1) {
			return;
		}
		
		sc_id.setText(col_id.getCellData(index).toString());
		sc_score.setText(col_score.getCellData(index).toString());
		sc_course.setText(col_course.getCellData(index).toString());

    	

    }

    @FXML
    public void editScore() {
    	
    	
    	try {
    		
        	con= SQLConnectScore.ConnectDB();
        	
        	String editId = sc_id.getText();
        	String editScore = sc_score.getText();
        	String editCourse = sc_course.getText();
        	

        	String sql = "update scores set id = '"+ editId+"', score = '"+editScore+"', course = '"+editCourse+"' where id = '"+editId+"' ";
        	
			pst = con.prepareStatement(sql);
			pst.execute();
			UpdateTable();
			System.out.println("Score Edit Success");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }

    @FXML
    public void removeScore() {
    	
    	con= SQLConnectScore.ConnectDB();
    	String sql = "DELETE from scores where id = ?";
    	try {
    		pst = con.prepareStatement(sql);
			pst.setString(1, sc_id.getText());
			pst.execute();
			UpdateTable();
			System.out.println("Score Remove Success");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
    	

    }
    
    @FXML
    public void displayAbout(ActionEvent event) throws IOException {
    	
    	main.changeScene("AboutSceneFinal.fxml");
    	
    }

    @FXML
    public void displayHomePage(ActionEvent event) throws IOException {
    	
    	main.changeScene("/HomePageScene.fxml");


    }

    @FXML
    public void sc_DisplayEdit(ActionEvent event) throws IOException {
    	
    	
    	main.changeScene("/EditScoreScene.fxml");
    	
    }

    @FXML
    public void sc_DisplayShow(ActionEvent event) throws IOException {
    	
    	main.changeScene("DisplayScoreScene.fxml");

    }
    
    @FXML
    public void studentDisplayAdd(ActionEvent event) throws IOException {
    	
    	main.changeScene("/AddStudent.fxml");

    }
    
    @FXML
    public void studentDisplayManage(ActionEvent event) throws IOException {
    	
    	main.changeScene("/ManageStudent.fxml");

    }
    
    @FXML
    public void courseDisplayManage(ActionEvent event) throws IOException {
    	
    	main.changeScene("/ManageCourse.fxml");

    }
    
    @FXML
    public void courseDisplayAdd(ActionEvent event) throws IOException {
    	
    	main.changeScene("/Addcouurse.fxml");

    }
    
    
    public void UpdateTable() {
    	col_id.setCellValueFactory(new PropertyValueFactory<Score,Integer>("id"));
    	col_course.setCellValueFactory(new PropertyValueFactory<Score,String>("course"));
    	col_score.setCellValueFactory(new PropertyValueFactory<Score,Integer>("score"));
		
    	listM = SQLConnectScore.getDatausers();
    	sc_table.setItems(listM);
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    	UpdateTable();


	}

}

