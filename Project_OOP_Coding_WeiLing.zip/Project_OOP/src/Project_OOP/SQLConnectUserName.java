package Project_OOP;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.swing.JOptionPane;

public class SQLConnectUserName {
	
	
	Connection con= null;
	
	public static Connection ConnectDB() {
		String url = "jdbc:sqlite:C:/Users/ongwe/Desktop/UserName2.db";
		
		try {
			Class.forName("org.sqlite.JDBC");
			Connection con = DriverManager.getConnection(url);
			System.out.println("Connection Username Established");
			//JOptionPane.showMessageDialog(null,"Connection Established");
			//createNewTable();
			
			return con;
		} catch (Exception e)
		{
		//JOptionPane.showMessageDialog(null,e);
			return null;
		}
	}

}
