package Project_OOP;

public class Score {
	
	public String course;
	public int id, score;
	
	public Score(String course, int id, int score) {
		
		this.course = course;
		this.id = id;
		this.score = score;
		
	}
	
	public String getCourse() {
		return course;
	}
	
	public int getId() {
		return id;
	}
	
	public int getScore() {
		return score;
	}
	
	public void setCourse(String course) {
		this.course = course;
	}
	
	public void setId(int id) {
		this.id = id;
	}
	
	public void setScore(int score) {
		this.score = score;
	}
	

}
