package Project_OOP;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputControl;
import javafx.scene.control.cell.PropertyValueFactory;

public class DisplayScore_Controller implements Initializable, ChangeScene{
	
	Student_Information_System main = new Student_Information_System();
	
    @FXML
    public TableView<Score> display_table;

    @FXML
    public TableColumn<Score, Integer> col_id;

    @FXML
    public TableColumn<Score, String> col_course;

    @FXML
    public TableColumn<Score, Integer> col_score;
    
    @FXML
    public TextField txtSearch;
    
    //ObservableList<Score> listM = FXCollections.observableArrayList();
    
    ObservableList<Score> listM;
    ObservableList<Score> searchList;
    
    Connection con = SQLConnectScore.ConnectDB();
    
    public void UpdateTable() {
    	col_id.setCellValueFactory(new PropertyValueFactory<Score,Integer>("id"));
    	col_course.setCellValueFactory(new PropertyValueFactory<Score,String>("course"));
    	col_score.setCellValueFactory(new PropertyValueFactory<Score,Integer>("score"));
		
    	listM = SQLConnectScore.getDatausers();
    	display_table.setItems(listM);
    }
    
    public void search() {
    	col_id.setCellValueFactory(new PropertyValueFactory<Score,Integer>("id"));
    	col_course.setCellValueFactory(new PropertyValueFactory<Score,String>("course"));
    	col_score.setCellValueFactory(new PropertyValueFactory<Score,Integer>("score"));
    	
    	searchList = SQLConnectScore.getDatausers();
    	display_table.setItems(searchList);
    	FilteredList<Score>filteredData = new FilteredList<>(searchList, b->true);
    	txtSearch.textProperty().addListener((observable, oldValue, newValue) -> {
    		filteredData.setPredicate(person-> {
    			if (newValue == null || newValue.isEmpty()) {
    				return true;
    			}
    			String lowerCaseFilter = newValue.toLowerCase();
    			
    			if (person.getCourse().toLowerCase().indexOf(lowerCaseFilter) != -1) {
    				return true;
    			}
    			else if (String.valueOf(person.getId()).indexOf(lowerCaseFilter) != -1) {
    				return true;
    			}
    			else {
    				return false;
    			}
 
    			
    		});
    	});
    	
    	SortedList<Score> sortedData = new SortedList<>(filteredData);
    	sortedData.comparatorProperty().bind(display_table.comparatorProperty());
    	display_table.setItems(sortedData);
    	
    	
    	
    	
    	
    	
    	
    }
    
    /*@FXML
    public void searchScore(ActionEvent event) {

    }*/
    
    

	
    @FXML
    public void displayAbout(ActionEvent event) throws IOException {
    	
    	main.changeScene("AboutSceneFinal.fxml");

    }

    @FXML
    public void displayHomePage(ActionEvent event) throws IOException {

    	main.changeScene("/HomePageScene.fxml");

    }


    @FXML
    public void sc_DisplayEdit(ActionEvent event) throws IOException {
    	
    	main.changeScene("/EditScoreScene.fxml");

    }

    @FXML
    public void sc_DisplayShow(ActionEvent event) throws IOException {
    	
    	main.changeScene("DisplayScoreScene.fxml");

    }

    
    /*public void logout(ActionEvent event) throws IOException {
    	
    	main.changeScene("/LoginScene.fxml");
    	
    }*/

    @FXML
	public void studentDisplayAdd(ActionEvent event) throws IOException {
	
		main.changeScene("/AddStudent.fxml");
		
	}

    @FXML
	public void studentDisplayManage(ActionEvent event) throws IOException {
	
    	
    	main.changeScene("/ManageStudent.fxml");
		
	}

    @FXML
	public void courseDisplayManage(ActionEvent event) throws IOException {
		
    	
    	main.changeScene("/ManageCourse.fxml");
		
	}

    @FXML
	public void courseDisplayAdd(ActionEvent event) throws IOException {

    	main.changeScene("/Addcouurse.fxml");
		
	}
    
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {

		
		
		UpdateTable();
		search();
		
	}
	
	
	

}
