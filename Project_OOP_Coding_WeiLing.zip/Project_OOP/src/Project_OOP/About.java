package Project_OOP;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;

public class About implements ChangeScene {
	
	Student_Information_System main = new Student_Information_System();
	
	@FXML
	public Label aboutLabel;
	
	//public void changeScene() 
	

    @FXML
    public void displayAbout(ActionEvent event) throws IOException {
    	
    	main.changeScene("AboutScene.fxml");

    }

    @FXML
    public void displayHomePage(ActionEvent event) throws IOException {

    	main.changeScene("HomePageScene.fxml");

    }


    @FXML
    public void sc_DisplayEdit(ActionEvent event) throws IOException {
    	
    	main.changeScene("/EditScoreScene.fxml");

    }

    @FXML
    public void sc_DisplayShow(ActionEvent event) throws IOException {
    	
    	main.changeScene("DisplayScoreScene.fxml");

    }

    
    /*public void logout(ActionEvent event) throws IOException {
    	
    	main.changeScene("/LoginScene.fxml");
    	
    }*/

    @FXML
	public void studentDisplayAdd(ActionEvent event) throws IOException {
	
		main.changeScene("/AddStudent.fxml");
		
	}

    @FXML
	public void studentDisplayManage(ActionEvent event) throws IOException {
	
    	
    	main.changeScene("/ManageStudent.fxml");
		
	}

    @FXML
	public void courseDisplayManage(ActionEvent event) throws IOException {
		
    	
    	main.changeScene("/ManageCourse.fxml");
		
	}

    @FXML
	public void courseDisplayAdd(ActionEvent event) throws IOException {

    	main.changeScene("/Addcouurse.fxml");
		
	}

}
