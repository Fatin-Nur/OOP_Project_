package Project_OOP;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class SignUpController {
	
	Student_Information_System main = new Student_Information_System();
	
	
    @FXML
    public Label sgLabel;

    @FXML
    public PasswordField rgPassword;

    @FXML
    public TextField rgUsername;

    @FXML
    public Button signUpButton;

    @FXML
    public Text login;
    
	Connection con = null;
	ResultSet rs = null;
	PreparedStatement pst = null;

    @FXML
    public void LogIn(MouseEvent event) throws IOException {
    	
    	
    	main.changeScene("/LoginScene.fxml");

    }
    
    @FXML
    public void userSignUp(ActionEvent event) {
    	
    	con = SQLConnectUserName.ConnectDB();
    	String sql = "insert into users (username,password) values (?,?)";
		try {
			pst = con.prepareStatement(sql);
			pst.setString(1, rgUsername.getText());
			pst.setString(2, rgPassword.getText());
			pst.execute();
			
			System.out.println("Users added");
			sgLabel.setText("Signup Success");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	
    	
    }

}
