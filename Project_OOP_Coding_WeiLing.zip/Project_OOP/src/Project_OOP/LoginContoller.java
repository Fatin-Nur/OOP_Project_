package Project_OOP;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class LoginContoller implements Initializable{
	
	Student_Information_System main = new Student_Information_System();
	
    @FXML
    public Label alert;

    @FXML
    public PasswordField lgPassword;

    @FXML
    public TextField lg_username;

    @FXML
    public Button loginButton;
    
    @FXML
    public Button Register;
    
    @FXML
    public Text fx_signUp;
    
	Connection con = null;
	ResultSet rs = null;
	PreparedStatement pst = null;
	
	
    @FXML
    public void Login(ActionEvent event) throws IOException {
    	
    	
    	
    	con = SQLConnectUserName.ConnectDB();
    	String sql = "Select * from users where username = ? and password = ?";
    	
    	try {
			pst = con.prepareStatement(sql);
			pst.setString(1, lg_username.getText());
			pst.setString(2, lgPassword.getText());
			rs = pst.executeQuery();
			
			if(rs.next()) {
				
				alert.setText("Success Login");
				main.changeScene("/HomePageScene.fxml");
				
			}
			else {
				alert.setText("Wrong username or password");
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }
    
    
    
    
    
    @FXML
    public void signUp(MouseEvent event) throws IOException {
    	
    	
    	main.changeScene("/RegisterScene.fxml");

    }





	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
