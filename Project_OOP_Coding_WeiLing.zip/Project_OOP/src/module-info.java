module Project_OOP {
	requires javafx.graphics;
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.base;
	requires java.sql;
	requires java.desktop;
	exports Project_OOP;
}