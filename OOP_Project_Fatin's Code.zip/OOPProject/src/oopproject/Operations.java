package oopproject;

public interface Operations {

	public void Add();
	public void Edit();
	public void Remove();
	
	
}
