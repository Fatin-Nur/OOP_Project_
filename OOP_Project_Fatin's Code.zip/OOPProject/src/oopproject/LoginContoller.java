package oopproject;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class LoginContoller implements Initializable{
	
	Main main = new Main();
	
    @FXML
    public Label alert;

    @FXML
    public PasswordField lgPassword;

    @FXML
    public TextField lg_username;

    @FXML
    public Button loginButton;
    
    @FXML
    public Button Register;
    
    @FXML
    public Text fx_signUp;
    
	Connection con = null;
	ResultSet rs = null;
	PreparedStatement pst = null;
	
	

      	
    	
    	
   	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}

}
